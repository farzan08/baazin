 

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="table-responsive" style="margin-top: 15px;">
            <table class="table table-striped table-bordered  table-dark table-hover" style="max-width: 50%;margin: auto;">
                <caption style="text-align: center">
                    <h3 style="color: #1b1e21">(( اطلاعات کاربر ))</h3>
                </caption>
                <tbody>
                <tr>
                    <td>شناسه:</td>
                    <td><?php echo e($user->id); ?></td>
                </tr>
                <tr>
                    <td> نام: </td>
                    <td> <?php echo e($user -> name); ?> </td>
                </tr>
                <tr>
                    <td> نام خانوادگی: </td>
                    <td> <?php echo e($user -> family); ?> </td>
                </tr>
                <tr>
                    <td> نام کاربری: </td>
                    <td> <?php echo e($user -> username); ?> </td>
                </tr>
                <tr>
                    <td> تلفن همراه: </td>
                    <td> <?php echo e($user -> cellphone); ?> </td>
                </tr>
                <tr>
                    <td> نقش: </td>
                    <?php if($user -> role == 1): ?>
                        <td> ادمین </td>
                    <?php else: ?>
                        <td> کاربر عادی </td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td> وضعیت: </td>
                    <?php if($user -> trash == 1): ?>
                        <td> در سطل زباله (: </td>
                    <?php elseif($user->verify==0): ?>
                        <td> تایید نشده (: </td>
                    <?php else: ?>
                        <td> فعال </td>
                    <?php endif; ?>
                </tr>
                </tbody>
            </table>
        </div>
        <div style="text-align: center;margin-top: 5px;">
            <a href="<?php echo e(route('users.edit',$user -> id)); ?>" class="btn bt-profile" role="button">ویرایش کاربر</a>
            <a href="<?php echo e(route('users.games',$user -> id)); ?>" class="btn bt-profile" role="button">بازی‌های کاربر</a>


          <!-- Button delete modal -->
            <a class="btn bt-profile" data-toggle="modal"  href="#"  onclick="document.getElementById('id03').style.display='flex'" style="width:auto;">
                حذف حساب کاربری
            </a>

            <?php if($user -> trash == 1): ?>
                <!-- Button  replace from trash modal -->
                    <a class="btn bt-profile" data-toggle="modal"  href="#"  onclick="document.getElementById('id05').style.display='flex'" style="width:auto;">
                        بازگردانی از زباله دان
                    </a>

                <a href="<?php echo e(route('users.trash')); ?>" class="btn btn-dark"><?php echo e(__('بازگشت')); ?></a>
            <?php elseif($user->trash == 0): ?>
            <!-- Button  move to trash modal -->
                <a class="btn bt-profile" data-toggle="modal"  href="#"  onclick="document.getElementById('id04').style.display='flex'" style="width:auto;">
                    انتقال به زباله دان
                </a>
                <a href="<?php echo e(route('users.index')); ?>" class="btn bt-profile"><?php echo e(__('بازگشت')); ?></a>
            <?php endif; ?>

            <!-- Delete Modal -->
            <div id="id03" class="modal container-fluid">

                <form method="post" class="modal-content" style="height: fit-content;padding: 5px;" action="<?php echo e(route('users.destroy',$user->id)); ?>" aria-label="<?php echo e(__('deleteUser')); ?>">
                    <?php echo e(method_field('delete')); ?>

                    <?php echo csrf_field(); ?>
                    <div class="container-fluid per  del-style" style="    width: 100%;margin-top: 0;height: 100px;">
                        <span onclick="document.getElementById('id03').style.display='none'" class="close" title="بستن">&times;</span>
                        <p> آیا نسبت به حذف حساب کاربری این کاربر مطمئن هستید؟</p>
                        <input class="btn btn-danger"  type="submit" value="حذف حساب کاربری">
                    </div>
                </form>
            </div>
            <!-- trash Modal -->
            <div id="id04" class="modal container-fluid">
                <form method="post"  class="modal-content" style="height: fit-content;padding: 5px;" action="<?php echo e(route('users.moveToTrash',$user->id)); ?>" aria-label="<?php echo e(__('moveToTrash')); ?>">
                    <?php echo e(method_field('put')); ?>

                    <?php echo csrf_field(); ?>
                    <div class="container-fluid per  del-style" style="    width: 100%;margin-top: 0;height: 100px;">
                        <span onclick="document.getElementById('id04').style.display='none'" class="close" title="بستن">&times;</span>
                        <p>آیا نسبت به انتقال این حساب کاربری به زباله دان مطمئن هستید؟</p>
                        <input class="btn btn-danger" type="submit" value="انتقال به زباله دان">
                    </div>
                </form>
            </div>
            <!-- replace Modal -->
            <div id="id05" class="modal container-fluid">
                <form method="post" class="modal-content" style="height: fit-content;padding: 5px;" action="<?php echo e(route('users.replaceFromTrash',$user->id)); ?>" aria-label="<?php echo e(__('replaceFromTrash')); ?>">
                    <?php echo e(method_field('put')); ?>

                    <?php echo csrf_field(); ?>
                    <div class="container-fluid per  del-style" style="    width: 100%;margin-top: 0;height: 100px;">
                        <span onclick="document.getElementById('id05').style.display='none'" class="close" title="بستن">&times;</span>
                        <p>آیا نسبت به بازگردانی این حساب کاربری از زباله دان مطمئن هستید؟</p>
                        <input class="btn btn-danger" type="submit" value="بازگردانی از زباله دان">
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>