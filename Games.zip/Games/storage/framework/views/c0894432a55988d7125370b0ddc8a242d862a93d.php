<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('ویرایش اطلاعات کاربر')); ?></div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('users.update',$user->id)); ?>" aria-label="<?php echo e(__('editUser')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('put')); ?>


                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('نام:')); ?></label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control<?php echo e($errors -> has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($user -> name); ?>" required autofocus>

                                    <?php if($errors -> has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors -> first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="family" class="col-md-4 col-form-label text-md-right"><?php echo e(__('نام خانوادگی:')); ?></label>

                                <div class="col-md-6">
                                    <input id="family" type="text" class="form-control<?php echo e($errors -> has('family') ? ' is-invalid' : ''); ?>" name="family" value="<?php echo e($user -> family); ?>" required autofocus>

                                    <?php if($errors->has('family')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors -> first('family')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="username" class="col-md-4 col-form-label text-md-right"><?php echo e(__('نام کاربری:')); ?></label>

                                <div class="col-md-6">
                                    <input id="username" type="text" class="form-control<?php echo e($errors -> has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e($user -> username); ?>" required autofocus>

                                    <?php if($errors -> has('username')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors -> first('username')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cellphone" class="col-md-4 col-form-label text-md-right"><?php echo e(__('شماره همراه:')); ?></label>

                                <div class="col-md-6">
                                    <input id="cellphone" type="text" class="form-control<?php echo e($errors -> has('cellphone') ? ' is-invalid' : ''); ?>" name="cellphone" value="<?php echo e($user -> cellphone); ?>" required autofocus>

                                    <?php if($errors -> has('cellphone')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors -> first('cellphone')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary"><?php echo e(__(' ویرایش اطلاعات کاربر ')); ?></button>
                                    <a href="<?php echo e(route('users.show',$user->id)); ?>" class="btn btn-dark"><?php echo e(__('بازگشت')); ?></a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>