<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('ثبت کاربر')); ?></div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('users.store')); ?>" aria-label="<?php echo e(__('creat user')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('نام:')); ?></label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control<?php echo e($errors -> has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                    <?php if($errors -> has('name')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors -> first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="family" class="col-md-4 col-form-label text-md-right"><?php echo e(__('نام خانوادگی:')); ?></label>

                                <div class="col-md-6">
                                    <input id="family" type="text" class="form-control<?php echo e($errors -> has('family') ? ' is-invalid' : ''); ?>" name="family" value="<?php echo e(old('family')); ?>" required autofocus>

                                    <?php if($errors -> has('family')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors -> first('family')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="username" class="col-md-4 col-form-label text-md-right"><?php echo e(__('نام کاربری:')); ?></label>

                                <div class="col-md-6">
                                    <input id="username" type="text" class="form-control<?php echo e($errors -> has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" required autofocus>

                                    <?php if($errors -> has('username')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors -> first('username')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cellphone" class="col-md-4 col-form-label text-md-right"><?php echo e(__('شماره همراه:')); ?></label>

                                <div class="col-md-6">
                                    <input id="cellphone" type="text" class="form-control<?php echo e($errors -> has('cellphone') ? ' is-invalid' : ''); ?>" name="cellphone" value="<?php echo e(old('cellphone')); ?>" required autofocus>

                                    <?php if($errors -> has('cellphone')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors -> first('cellphone')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group row">
                                <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('رمز عبور:')); ?></label>

                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control<?php echo e($errors -> has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                    <?php if($errors -> has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors -> first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('تکرار رمز عبور:')); ?></label>

                                <div class="col-md-6">
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                </div>
                            </div>
                            <button type="submit" class="btn bt-profile">
                                <?php echo e(__('اضافه کردن بازی')); ?>

                            </button>
                            <a href="<?php echo e(route('dashboard')); ?>" class="btn bt-profile"><?php echo e(__('بازگشت')); ?></a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>