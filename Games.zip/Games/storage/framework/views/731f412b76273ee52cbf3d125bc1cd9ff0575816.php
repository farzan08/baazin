<?php $__env->startSection('content'); ?>
    <section id="team" class="pb-5">
        <div class="container">
            <h5 class="section-title h1">بازی ها</h5>
            <div class="row">
                <!-- Team member -->
                <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-12 col-sm-6 col-md-4 float-right">
                        <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                            <div class="mainflip">
                                <div class="frontside">
                                    <div class="card">
                                        <div class="card-body text-center card-pad">
                                            <p><img class=" img-fluid" src="picture/2.jpg" alt="card image"></p>
                                            <h4 class="card-title"><?php echo e($game->name); ?></h4>

                                            <p class="card-text persian-card"></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="backside ">
                                    <div class="card ">
                                        <div class="card-body text-center mt-4 ">
                                            <h4 class="card-title "><?php echo e($game->name); ?></h4>
                                            <p class="card-text persian-card">
                                                <?php echo e($game->summary); ?>

                                                نیاز به محتوا
                                            </p>

                                        </div>
                                        <div class="card-footer footercard ">
                                            <a href="<?php echo e(route('games.show',$game->id)); ?>" class="btn btn-primary btn-md"><i class="fa fa-plus plus-icon "> &nbsp;صفحه بازی</i></a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- ./Team member -->




            </div>

        </div>
    </section>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>