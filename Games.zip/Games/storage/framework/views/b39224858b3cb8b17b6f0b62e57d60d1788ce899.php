<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="table-responsive" style="margin-top: 15px;">
            <table class="table table-striped table-bordered  table-dark table-hover" style="max-width: 50%;margin: auto;">
                <caption style="text-align: center">
                    <h3 style="color: #1b1e21">(( بازی‌های کاربر ))</h3>
                </caption>
                <thead>
                    <td class="text-center">شماره</td>
                    <td class="text-center">نام بازی</td>
                </thead>
                <tbody>
                <?php $__currentLoopData = $user->games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($loop->index + 1); ?></td>
                        <td class="text-center"><?php echo e($game->name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div style="text-align: center;margin-top: 5px;">
            <a href="<?php echo e(route('users.showgames',$user->id)); ?>" class="btn bt-profile"><?php echo e(__('اضافه کردن بازی')); ?></a>
            <a href="<?php echo e(route('users.show',$user->id)); ?>" class="btn bt-profile"><?php echo e(__('بازگشت')); ?></a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>