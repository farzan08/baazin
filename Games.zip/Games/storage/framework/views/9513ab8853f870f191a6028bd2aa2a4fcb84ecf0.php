<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


    <link rel="stylesheet" href="<?php echo e(url('css/ui/index.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/ui/signup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/ui/navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/ui/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/ui/comments.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/ui/panel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/ui/profile.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/ui/gamecard.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/ui/login.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/ui/slider.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/ui/util.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/ui/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/ui/Font/font-face.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/ui/shabnam-font-master/dist/font-face.css')); ?>">

    
   
    
    <script src="<?php echo e(url('js/ui/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/ui/script.js')); ?>"></script>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'بازین')); ?></title>

    


</head>
<body style="direction: rtl;text-align: right;">
    <div id="app">

        
        <nav class="navbar navbar-color">
            <div class="container-fluid mob-v">
                
                <div class="navbar-header  nav-head-mob collaps-style ul-style ">
                    <button type="button" class="navbar-toggle icon-color" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                </div>

                
                
                <div class="collapse navbar-collapse " id="myNavbar">
                    <ul class="nav navbar-nav  navbar-right persian ul-style">
                        <li class="active">
                            <a href="<?php echo e(url('/')); ?>" class="nav-item-color">صفحه اصلی</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('games.index')); ?>" class="nav-item-color">بازی‌ها</a>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-left persian">
                        <?php if(auth()->guard()->check()): ?>
                            <li class="dropdown">
                                <a id="navbarDropdown" class="dropdown-toggle nav-item-color" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user() -> username); ?> <span class="caret"></span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right " style="min-width: fit-content;padding: 0;" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item btn bt-profile" style="padding: 5px;" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                        <?php echo e(__('خروج از حساب کاربری')); ?>

                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                            <?php if(Auth::user()->role == 1): ?>
                                <li><a class="nav-item-color" href="<?php echo e(url('/dashboard')); ?>"><?php echo e(__('مدیریت سایت')); ?></a></li>
                            <?php endif; ?>
                            <li class=" active">
                                <a class="nav-item-color" href="<?php echo e(url('/panel')); ?>"> پنل کاربری </a>
                            </li>
                            

                        <?php else: ?>
                            
                            <li>
                                <a href="#" class="nav-item-color" onclick="document.getElementById('id01').style.display='flex'" style="width:auto;">
                                    <span class="glyphicon glyphicon-log-in"></span> ورود
                                </a>
                            </li>
                            <li>
                                <a class="nav-item-color" href="<?php echo e(route('register')); ?>"> عضویت </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        
        <?php if(session('warning')): ?>
            <div class="alert alert-danger alert-dismissible" style="direction: rtl;text-align: right;margin-bottom: 0;" >
                <button type="button" class="close alert-type" data-dismiss="alert">&times;</button>
                <?php echo e(session('warning')); ?>


            </div>
        <?php elseif(session('success')): ?>
            <div class="alert  alert-success alert-dismissible" style="direction: rtl;text-align: right;margin-bottom: 0;">
                <button type="button" class="close alert-type" data-dismiss="alert">&times;</button>
                <?php echo e(session('success')); ?>


            </div>
        <?php endif; ?>

        <div id="id01" class="modal container-fluid">
            <form class="modal-content animate style-login" method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="imgcontainer">
                    <span onclick="document.getElementById('id01').style.display='none'" class="close" title="بستن">&times;</span>
                    <img src="picture/avatar.png" alt="Avatar" class="avatar">
                </div>

                <div class="container-fluid per">
                    
                    <input id="username" type="text" placeholder="نام کاربری" class="form-control<?php echo e($errors -> has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" required autofocus>
                    <?php if($errors -> has('username')): ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors -> first('username')); ?></strong>
                                    </span>
                    <?php endif; ?>

                    
                    <input id="password" type="password" placeholder="رمز عبور" class="form-control<?php echo e($errors -> has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                    <?php if($errors -> has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors -> first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                    <label for="checkbox-password">
                        <input type="checkbox"  id="checkbox-password" name="remember"> نمایش پسورد
                    </label>
                    <label for="remember">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>مرا به خاطر بسپار
                    </label>


                    <button type="submit" class="btn bt-profile">ورود</button>

                </div>
                <div class="container-fluid per">
                    <span class="psw"> کلمه عبور را <a href="<?php echo e(route('password.request')); ?>">فراموش</a> کرده‌اید؟</span>
                </div>
                <div class="container-fluid lable-pad style-sign-exit">
                    <a class="bt-profile btn cancelbtn" href="<?php echo e(route('register')); ?>">عضویت</a>
                    <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn btn bt-profile">خروج</button>
                </div>
            </form>
        </div>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <footer class="py-5 bg-light footer-color">
            <div class="container">
                <p class="m-0 text-center text-dark"> &copy.تمام حقوق معنوی این اثر محفوظ است</p>
                <p class="m-0 text-center text-dark">طراحان:  سید فرزان فخرایی  FARZAN.FIVB@YAHOO.COM و امیر سرتیپی</p>
            </div>
        </footer>
    </div>
</body>
</html>
