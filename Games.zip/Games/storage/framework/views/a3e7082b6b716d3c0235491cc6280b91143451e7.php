<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">داشبورد</div>
                <div class="card-body">
                        <a href="<?php echo e(route('users.index')); ?>" class="btn bt-profile"><?php echo e(__('مدیریت کاربران')); ?></a>
                        <a href="<?php echo e(route('users.trash')); ?>" class="btn bt-profile"><?php echo e(__('زباله دان کاربران')); ?></a>
                        <a href="<?php echo e(route('users.create')); ?>" class="btn bt-profile"><?php echo e(__('ایجاد کاربر جدید')); ?></a>
                        <a href="<?php echo e(route('comments.sent')); ?>" class="btn bt-profile"><?php echo e(__(' کامنت‌ها منتشر شده')); ?></a>
                        <a href="<?php echo e(route('comments.index')); ?>" class="btn bt-profile"><?php echo e(__(' کامنت‌ها منتشر نشده')); ?></a>
                        <a href="<?php echo e(route('sms-admin')); ?>" class="btn bt-profile"><?php echo e(__(' مدیریت پیام ها')); ?></a>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>