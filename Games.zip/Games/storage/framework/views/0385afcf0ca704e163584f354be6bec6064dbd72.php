<?php $__env->startSection('content'); ?>
    <div class="container-login100" style="min-height: 76.8vh;">
        <div class="wrap-login100">
            <form method="POST" class="login100-form" action="<?php echo e(route('verification.check')); ?>" aria-label="<?php echo e(__('verification sms')); ?>">
                <?php echo csrf_field(); ?>
                
                <div class="wrap-input100">
                    <label for="sms" class="col-form-label text-md-right"><?php echo e(__('کد ارسال شده:')); ?></label>
                    <input id="sms" type="text" class="form-control<?php echo e($errors -> has('sms') ? ' is-invalid' : ''); ?>" name="sms"  required autofocus>
                    <?php if(session('error')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong> <?php echo e(session('error')); ?></strong>
                        </span>
                    <?php endif; ?>
                    <?php if($errors -> has('sms')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors -> first('sms')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="container-login100-form-btn">
                    <input type="submit" class="btn bt-profile" value="ارسال" style="margin-left: 7px;">
                    <a href="<?php echo e(url('/register')); ?>" class="btn bt-profile">
                    <?php echo e(__('بازگشت')); ?>

                    </a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>