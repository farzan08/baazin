<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">مدیریت کاربران</div>
                    <div class="card-body">
                        <div class="table-responsive" style="margin-top: 15px;">
                            <table class="table table-striped table-bordered  table-dark table-hover" style="max-width: 100%;margin: auto;">
                                <caption style="text-align: center">
                                    <h3 style="color: #1b1e21">(( اطلاعات کاربران ))</h3>
                                </caption>
                                <thead>
                                    <td class="text-center">شماره</td>
                                    <td class="text-center">نام</td>
                                    <td class="text-center">نام خانوادگی</td>
                                    <td class="text-center">نام کاربری</td>
                                    <td class="text-center">نمایش اطلاعات</td>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->index + 1); ?></td>
                                    <td class="text-center"><?php echo e($user->name); ?></td>
                                    <td class="text-center"><?php echo e($user->family); ?></td>
                                    <td class="text-center"><?php echo e($user->username); ?></td>
                                    <td class="text-center"><a href="<?php echo e(route('users.show',$user->id)); ?>">مشاهده</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($users->links()); ?>

                            <a href="<?php echo e(route('dashboard')); ?>" class="btn bt-profile"><?php echo e(__('بازگشت')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>