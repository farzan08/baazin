<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="table-responsive" style="margin-top: 15px;">
            <table class="table table-striped table-bordered  table-dark table-hover" style="max-width: 50%;margin: auto;">
                <caption style="text-align: center">
                    <h3 style="color: #1b1e21">(( اطلاعات کامنت ))</h3>
                </caption>
                <tbody>
                <tr>
                    <td>شناسه:</td>
                    <td><?php echo e($comment->id); ?></td>
                </tr>
                <tr>
                    <td> نویسنده: </td>
                    <td> <?php echo e($comment -> auther); ?> </td>
                </tr>
                <tr>
                    <td> دیدگاه: </td>
                    <td> <?php echo e($comment -> body); ?> </td>
                </tr>
                <tr>
                    <td> نام بازی: </td>
                    <td> <?php echo e($comment ->game->name); ?> </td>
                </tr>
                <tr>
                    <td> وضعیت: </td>
                    <?php if($comment -> show == 1): ?>
                        <td> منتشر شده </td>
                    <?php else: ?>
                        <td> منتشر نشده </td>
                    <?php endif; ?>
                </tr>
                </tbody>
            </table>
        </div>
        <div style="text-align: center;margin-top: 5px;">
            


            <!-- Button delete comment modal -->
            <a class="btn bt-profile" data-toggle="modal"  href="#"  onclick="document.getElementById('id06').style.display='flex'" style="width:auto;">حذف کامنت</a>

        <?php if($comment -> show == 0): ?>
            <!-- Button  send comment modal -->
            <a class="btn bt-profile" data-toggle="modal"  href="#"  onclick="document.getElementById('id07').style.display='flex'" style="width:auto;">انتشار دیدگاه</a>
            <a href="<?php echo e(route('comments.index',$comment->id)); ?>" class="btn bt-profile"><?php echo e(__('بازگشت')); ?></a>
        <?php elseif($comment->show == 1): ?>
            <!-- Button  not send comment modal -->
            <a class="btn bt-profile" data-toggle="modal"  href="#"  onclick="document.getElementById('id08').style.display='flex'" style="width:auto;">منتشر نکردن دیدگاه</a>
            <button type="button" class="btn bt-profile" data-toggle="modal" data-target="#unsendModal"></button>
                <a href="<?php echo e(route('comments.index')); ?>" class="btn bt-profile"><?php echo e(__('بازگشت')); ?></a>
        <?php endif; ?>


            <!-- Delete Modal -->
                <div id="id06" class="modal container-fluid">
                    <form method="post" class="modal-content" style="height: fit-content;padding: 5px;" action="<?php echo e(route('comments.destroy',$comment->id)); ?>" aria-label="<?php echo e(__('deleteComment')); ?>">
                        <?php echo e(method_field('delete')); ?>

                        <?php echo csrf_field(); ?>
                        <div class="container-fluid per  del-style" style="    width: 100%;margin-top: 0;height: 100px;">
                            <span onclick="document.getElementById('id06').style.display='none'" class="close" title="بستن">&times;</span>
                            <p>آیا نسبت به حذف این کامنت مطمئن هستید.</p>
                            <input class="btn btn-danger" type="submit" value="حذف کامنت">
                        </div>
                    </form>
                </div>

                <!-- send Modal -->
                <div id="id07" class="modal container-fluid">
                    <form method="post"  class="modal-content" style="height: fit-content;padding: 5px" action="<?php echo e(route('comments.send',$comment->id)); ?>" aria-label="<?php echo e(__('sendComment')); ?>">
                        <?php echo e(method_field('put')); ?>

                        <?php echo csrf_field(); ?>
                        <div class="container-fluid per  del-style" style="    width: 100%;margin-top: 0;height: 100px;">
                            <span onclick="document.getElementById('id07').style.display='none'" class="close" title="بستن">&times;</span>
                            <p>آیا نسبت به انتشار این کامنت مطمئن هستید؟</p>
                            <input class="btn btn-danger" type="submit" value="انتشار کامنت">
                        </div>
                    </form>
                </div>
            <!-- unsend Modal -->
                <div id="id08" class="modal container-fluid">
                    <form method="post" class="modal-content" style="height: fit-content;padding: 5px;" action="<?php echo e(route('comments.unsend',$comment->id)); ?>" aria-label="<?php echo e(__('unsendComment')); ?>">
                        <?php echo e(method_field('put')); ?>

                        <?php echo csrf_field(); ?>
                        <div class="container-fluid per  del-style" style="    width: 100%;margin-top: 0;height: 100px;">
                            <span onclick="document.getElementById('id08').style.display='none'" class="close" title="بستن">&times;</span>
                            <p>آیا نسبت به منتشر نکردن این کامنت مطمئن هستید؟</p>
                            <input class="btn btn-dark" type="submit" value="منتشر نکردن">
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>