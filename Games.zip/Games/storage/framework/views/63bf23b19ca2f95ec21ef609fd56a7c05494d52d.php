<?php $__env->startSection('content'); ?>
   <div class="product-content container-fluid product-wrap clearfix product-deatil cnt-style">
        <div class="row per-page ">
            <div class="col-sm-11 col-md-11 col-lg-11">
                <div class="product-image">
                    <img src="<?php echo e(url('picture/630111.JPG')); ?>" class="img-fluid img-style" alt="Sample photo">
                    نیاز به محتوا
                </div>
            </div>
            <div class="col-md-11 col-sm-11 col-xs-11 game-text">
                <h2 class="name"> <?php echo e($game->name); ?></h2>
                <hr>
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <strong><h1>درباره‌ی بازی</h1></strong>
                    <p>
                        <?php echo e($game->about); ?>

                        نیاز به محتوا
                    </p>
                    <hr>
                </div>
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <h4>قیمت محصول : 15000 هزار تومن</h4>
                    <a href="<?php echo e(route('startGame',$game->name)); ?>" class="btn btn-hero btn-lg">شروع بازی </a>
                </div>
                <br>

            </div>

        </div>
        <div class="cmsig">
            <form class="pagecm" method="POST" action="<?php echo e(route('storeComment',$game->id)); ?>" aria-label="<?php echo e(__('Comment')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group form-align">
                    <textarea class="form-control txtarea" placeholder="درباره‌ی بازی نظر دهید "></textarea>
                </div>
                <input type="submit" class="btn btn-hero btn-lg" value="ارسال نظر">
            </form>
            <hr>
        </div>


        <div class="media-body">
            <?php $__currentLoopData = $game->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well well-lg">
                <h4 class="media-heading text-uppercase reviews"><?php echo e($comment->auther); ?></h4>
                <p class="media-comment">
                    <?php echo e($comment->body); ?>

                </p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <hr>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>