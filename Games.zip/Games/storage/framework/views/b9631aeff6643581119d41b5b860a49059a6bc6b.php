<?php $__env->startSection('content'); ?>
<div class="limiter">
    <div class="container-login100">
        <div class="wrap-login100">
            <div class="login100-form-title" style="background-color: hsl(204, 79%, 20%);color: gold;">عضویت
            </div>
            <form method="POST" action="<?php echo e(route('register')); ?>" class="validate-input login100-form"  aria-label="<?php echo e(__('Register')); ?>">
                <?php echo csrf_field(); ?>

                <div class="wrap-input100 validate-form " datfa-validate="name is required">

                    <label for="name"><?php echo e(__('نام:')); ?></label>
                        <input id="name" type="text" class="input100 form-control<?php echo e($errors -> has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                        <?php if($errors -> has('name')): ?>
                                <strong style="color:red;"><?php echo e($errors -> first('name')); ?></strong>
                        <?php endif; ?>
                </div>
                <div class="wrap-input100 validate-input" data-validate="family is required">
                    <label for="family"><?php echo e(__('نام خانوادگی:')); ?></label>
                        <input id="family" type="text" class="input100 form-control<?php echo e($errors -> has('family') ? ' is-invalid' : ''); ?>" name="family" value="<?php echo e(old('family')); ?>" required autofocus>
                        <?php if($errors -> has('family')): ?>
                                <strong style="color:red;"><?php echo e($errors -> first('family')); ?></strong>
                        <?php endif; ?>
                </div>
                <div class="wrap-input100 validate-input" data-validate="username is required">
                    <label for="username"><?php echo e(__('نام کاربری:')); ?></label>
                        <input id="username" type="text" class="input100 form-control<?php echo e($errors -> has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" required autofocus>
                        <?php if($errors -> has('username')): ?>
                                <strong style="color:red;"><?php echo e($errors -> first('username')); ?></strong>
                        <?php endif; ?>
                </div>
                <div class="wrap-input100 validate-input" data-validate="cellphone is required">
                    <label for="cellphone"><?php echo e(__('شماره همراه:')); ?></label>
                        <input id="cellphone"  type="text" class="input100 form-control<?php echo e($errors -> has('cellphone') ? ' is-invalid' : ''); ?>" name="cellphone" value="<?php echo e(old('cellphone')); ?>" required autofocus>
                        <?php if($errors -> has('cellphone')): ?>
                                <strong style="color:red;"><?php echo e($errors -> first('cellphone')); ?></strong>
                        <?php endif; ?>
                </div>
                <div class="wrap-input100 validate-input" data-validate="password is required">

                    <label for="password"><?php echo e(__('رمز عبور:')); ?></label>
                        <input id="password" type="password" class="input100 form-control<?php echo e($errors -> has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                        <?php if($errors -> has('password')): ?>
                                <strong style="color:red;"><?php echo e($errors -> first('password')); ?></strong>
                        <?php endif; ?>
                </div>
                <div class="wrap-input100 validate-input" data-validate="password is required">
                    <label for="password-confirm"><?php echo e(__('تکرار رمز عبور:')); ?></label>
                        <input id="password-confirm" type="password" class="input100 form-control" name="password_confirmation" required>
                </div>
                <br><br>
                <div class="container-login100-form-btn">
                        <button type="submit" class="login100-form-btn">
                            <?php echo e(__('عضویت')); ?>

                        </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>