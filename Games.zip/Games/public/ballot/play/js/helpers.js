// YES, TAU.
Math.TAU = Math.PI*2;

// For the election sandbox code
function _icon(name){
	return "<img src='img/icon/"+name+".png'/>";
}