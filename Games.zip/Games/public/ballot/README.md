![](http://i.imgur.com/8ZzgDiV.png)

**TO BUILD A BETTER BALLOT**     
an interactive guide to alternative voting systems

**[play/read it here](http://ncase.me/ballot)**