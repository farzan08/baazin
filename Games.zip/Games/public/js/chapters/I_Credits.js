// 0 - INTRODUCTION
SLIDES.push(
{
	chapter: "Credits",
	clear:true,
	add:[

		// Background
		{
			type:"box",
			background:"#222"
		},

		// CREDITS
		{
			type:"box",
			text:"credits", x:0, y:0, w:960, h:540
		}

	]

}
);